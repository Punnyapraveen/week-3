import os
import asyncio
from typing import List
import google.generativeai as genai
import chromadb
from chromadb import PersistentClient

# ========== CONFIGURE GEMINI ==========
genai.configure(api_key="your_api_key")  # Replace with your actual Gemini API key
gemini_model = genai.GenerativeModel("gemini-2.0-flash")

# ========== LOAD DOCUMENTS ==========

def load_documents_from_folder(folder_path: str) -> List[tuple]:
    docs = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".txt"):
            path = os.path.join(folder_path, filename)
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            docs.append((filename, content))
    return docs

# ========== CHROMA CLIENT ==========
client = PersistentClient(path="chromadb_store")
collection_name = "faq_collection"

if collection_name in [col.name for col in client.list_collections()]:
    collection = client.get_collection(collection_name)
else:
    collection = client.create_collection(name=collection_name)

# ========== HELPERS ==========

def get_gemini_embedding(text: str) -> List[float]:
    import numpy as np
    return np.random.rand(768).tolist()

async def async_get_gemini_embedding(text: str) -> List[float]:
    return get_gemini_embedding(text)

# ========== INDEX DOCUMENTS ==========

async def index_documents(docs: List[tuple]):
    for i, (fname, text) in enumerate(docs):
        embedding = await async_get_gemini_embedding(text)
        collection.add(
            documents=[text],
            metadatas=[{"source": fname}],
            ids=[f"doc-{i}"],
            embeddings=[embedding]
        )
    print(f"✅ Indexed {len(docs)} documents.")

# ========== AGENTS ==========

class GeminiAgent:
    def __init__(self, name: str, tools: List, system_prompt: str):
        self.name = name
        self.tools = tools
        self.system_prompt = system_prompt

    async def run(self, input_text: str, history: List[str]) -> str:
        tool_outputs = ""
        for tool_func in self.tools:
            try:
                if asyncio.iscoroutinefunction(tool_func):
                    result = await tool_func(input_text)
                else:
                    result = tool_func(input_text)
                tool_outputs += f"\n🛠️ {tool_func.__name__} Output:\n{result}\n"
            except Exception as e:
                tool_outputs += f"\n❌ {tool_func.__name__} Failed: {str(e)}\n"

        prompt = (
            f"{self.system_prompt}\n"
            f"\n📝 Chat History:\n{chr(10).join(history)}"
            f"\n\n📥 Input:\n{input_text}"
            f"\n\n📤 Tool Results:\n{tool_outputs}"
        )

        response = gemini_model.generate_content(prompt)
        return response.text.strip()

# ========== TOOLS ==========

def rag_retriever(query: str) -> str:
    query_embedding = get_gemini_embedding(query)
    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=3,
        include=["documents", "metadatas"]
    )
    retrieved_docs = results['documents'][0]
    sources = [meta['source'] for meta in results['metadatas'][0]]
    combined_text = "\n---\n".join(retrieved_docs)
    return f"Retrieved Docs from {sources}:\n{combined_text}"

async def rag_retriever_async(query: str) -> str:
    return rag_retriever(query)

# ========== CHAT SYSTEM WITH LOGGING ==========

class RoundRobinGroupChat:
    def __init__(self, agents: List[GeminiAgent], max_turns=6, log_path="faq_chat_log.txt"):
        self.agents = agents
        self.max_turns = max_turns
        self.history = []
        self.log_path = log_path
        with open(self.log_path, "w", encoding="utf-8") as f:
            f.write("📝 FAQ Chat Log\n\n")

    async def chat(self, initial_input: str):
        query = initial_input
        self.history.append(f"[User]: {query}")
        self._log_to_file(f"[User]: {query}\n")

        for i in range(self.max_turns):
            agent = self.agents[i % len(self.agents)]
            print(f"\n🧠 [{agent.name}] is thinking...")
            response = await agent.run(query, self.history)
            self.history.append(f"[{agent.name}]: {response}")
            print(f"🗨️ [{agent.name}] says:\n{response}\n")
            self._log_to_file(f"[{agent.name}]: {response}\n")
            query = response

    def _log_to_file(self, line: str):
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")

# ========== MAIN FUNCTION ==========

async def main():
    folder = input("📂 Enter path to your FAQ documents folder (TXT files):\n>>> ").strip()
    if not os.path.isdir(folder):
        print("❌ Invalid folder path.")
        return

    docs = load_documents_from_folder(folder)
    if not docs:
        print("❌ No .txt files found in folder.")
        return

    print("Indexing documents...")
    await index_documents(docs)

    retriever_agent = GeminiAgent(
        name="RAGRetriever",
        tools=[rag_retriever],
        system_prompt="You are a Retriever agent. Retrieve relevant FAQ documents to answer queries."
    )

    query_handler_agent = GeminiAgent(
        name="QueryHandler",
        tools=[],
        system_prompt="You are a helpful FAQ chatbot. Use the retrieved documents to answer the user's question clearly."
    )

    chat = RoundRobinGroupChat(
        agents=[retriever_agent, query_handler_agent],
        max_turns=6,
        log_path="faq_chat_log.txt"
    )

    print("\nStart chatting with the FAQ bot! Ask any question or type 'exit' to quit.")
    user_input = input(">>> ").strip()
    while user_input.lower() != "exit":
        await chat.chat(user_input)
        user_input = input(">>> ").strip()

if __name__ == "__main__":
    asyncio.run(main())
